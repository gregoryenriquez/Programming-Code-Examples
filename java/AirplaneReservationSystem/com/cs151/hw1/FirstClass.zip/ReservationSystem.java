package com.cs151.hw1;

import java.io.IOException;

public class ReservationSystem {
	static public void main (String[] s) throws IOException
	{
		MenuStart start = new MenuStart();
	}
}
